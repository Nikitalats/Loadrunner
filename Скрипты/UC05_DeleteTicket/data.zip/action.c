Action()
{

	web_add_auto_header("Priority", 
		"u=4");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("x-telemetry-agent", 
		"Glean/61.2.0 (Rust on Windows)");

	web_custom_request("562de58a-a9d9-4005-9d64-47090446edd3", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/pageload/1/562de58a-a9d9-4005-9d64-47090446edd3", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t65.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":97,\"start_time\":\"2024-12-01T10:11:39.000+05:00\",\"end_time\":\"2024-12-01T10:16:06.360+05:00\",\"reason\":\"startup\"},\"client_info\":{\"telemetry_sdk_build\":\"61.2.0\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2024-03-01+05:00\",\"locale\":\"ru\",\"windows_build_number\":22631,\"architecture\":\"x86_64\",\"app_build\":\"20241121140525\",\"app_channel\":\"release\",\"app_display_version\":\"133.0\",\"os\":\"Windows\",\"os_version\":\"10.0"
		"\"},\"events\":[{\"timestamp\":0,\"category\":\"perf\",\"name\":\"page_load\",\"extra\":{\"response_time\":\"17888\",\"http_ver\":\"1\",\"glean_timestamp\":\"1733029998009\",\"using_webdriver\":\"false\",\"load_time\":\"97245\",\"time_to_request_start\":\"17870\",\"dns_lookup_time\":\"7\",\"features\":\"0\",\"load_type\":\"NORMAL\"}}]}", 
		LAST);

	web_custom_request("a9211a19-7a8c-482c-bc7c-393609cfda65", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/newtab/1/a9211a19-7a8c-482c-bc7c-393609cfda65", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t66.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":332,\"start_time\":\"2024-12-01T10:11:39.000+05:00\",\"end_time\":\"2024-12-01T10:16:06.425+05:00\",\"reason\":\"component_init\"},\"client_info\":{\"telemetry_sdk_build\":\"61.2.0\",\"os\":\"Windows\",\"os_version\":\"10.0\",\"app_build\":\"20241121140525\",\"app_channel\":\"release\",\"app_display_version\":\"133.0\",\"locale\":\"ru\",\"architecture\":\"x86_64\",\"first_run_date\":\"2024-03-01+05:00\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\""
		"windows_build_number\":22631,\"client_id\":\"4691bf69-838a-4a5f-8495-dd6b7e5add4b\"},\"metrics\":{\"boolean\":{\"pocket.is_signed_in\":false,\"newtab.search.enabled\":true,\"pocket.enabled\":true,\"newtab.weather_enabled\":true,\"pocket.sponsored_stories_enabled\":true,\"topsites.enabled\":true,\"topsites.sponsored_enabled\":true},\"quantity\":{\"topsites.rows\":1},\"string\":{\"newtab.locale\":\"ru\",\"newtab.newtab_category\":\"enabled\",\"newtab.homepage_category\":\"enabled\"},\"string_list\":"
		"{\"newtab.blocked_sponsors\":[]}}}", 
		LAST);

	web_custom_request("ded48103-e1b0-4288-b90a-e4ee2b8191e5", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/baseline/1/ded48103-e1b0-4288-b90a-e4ee2b8191e5", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t67.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":324,\"start_time\":\"2024-12-01T10:11:39.000+05:00\",\"end_time\":\"2024-12-01T10:16:06.499+05:00\",\"reason\":\"active\",\"experiments\":{\"1-click-set-to-default-existing-profiles-rollout\":{\"branch\":\"treatment-b\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"fx-accounts-ping-release-rollout-2\":{\"branch\":\"control\",\"extra\":{\"type\":\""
		"nimbus-rollout\"}},\"consolidated-search-configuration-row-desktop-relaunch\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"long-term-holdback-2024-h2-velocity-desktop\":{\"branch\":\"delivery\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"highlighting-in-pdfs-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"disable-ads-startup-cache\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"disable-redirects-for-authretries\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"encrypted-client-hello-fallback-mechanism\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"phc-rollout\":{\"branch\":\"rollout\",\"extra\":{\""
		"type\":\"nimbus-rollout\"}},\"fox-doodle-and-tail-fox-2024-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"extensions-migration-in-import-wizard-116-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"disabling-chips-for-v131\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"61.2.0\",\"locale\":\"ru\",\"app_display_version\":\"133.0\",\"os\":\"Windows\",\"architecture\":\"x86_64"
		"\",\"app_build\":\"20241121140525\",\"app_channel\":\"release\",\"os_version\":\"10.0\",\"client_id\":\"4691bf69-838a-4a5f-8495-dd6b7e5add4b\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2024-03-01+05:00\",\"windows_build_number\":22631},\"metrics\":{\"labeled_counter\":{\"glean.validation.pings_submitted\":{\"baseline\":1,\"dau-reporting\":1,\"events\":1,\"newtab\":1,\"pageload\":1,\"use-counters\":1}},\"uuid\":{\"legacy.telemetry.profile_group_id\":\""
		"b22cb673-aa6d-4c48-b971-b86830eeb2cf\",\"legacy.telemetry.client_id\":\"b22cb673-aa6d-4c48-b971-b86830eeb2cf\"},\"counter\":{\"browser.engagement.active_ticks\":14,\"browser.engagement.uri_count\":1}}}", 
		LAST);

	web_custom_request("13d7afe5-dcca-4943-8d51-1cd3ff1337b8", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/dau-reporting/1/13d7afe5-dcca-4943-8d51-1cd3ff1337b8", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t68.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":54,\"start_time\":\"2024-12-01T10:11:39.000+05:00\",\"end_time\":\"2024-12-01T10:16:06.506+05:00\",\"reason\":\"active\",\"experiments\":{\"fox-doodle-and-tail-fox-2024-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"disabling-chips-for-v131\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"fx-accounts-ping-release-rollout-2\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"phc-rollout\":{\"branch\""
		":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"1-click-set-to-default-existing-profiles-rollout\":{\"branch\":\"treatment-b\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"disable-redirects-for-authretries\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\""
		"nimbus-rollout\"}},\"consolidated-search-configuration-row-desktop-relaunch\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"disable-ads-startup-cache\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"extensions-migration-in-import-wizard-116-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"highlighting-in-pdfs-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"long-term-holdback-2024-h2-velocity-desktop\":{\"branch\":\"delivery\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"encrypted-client-hello-fallback-mechanism\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"61.2.0\",\"client_id\":\"4691bf69-838a-4a5f-8495-dd6b7e5add4b\",\"windows_build_number\":22631,\"app_display_version\":\"133.0\",\""
		"architecture\":\"x86_64\",\"locale\":\"ru\",\"app_build\":\"20241121140525\",\"app_channel\":\"release\",\"os\":\"Windows\",\"os_version\":\"10.0\",\"first_run_date\":\"2024-03-01+05:00\",\"build_date\":\"1970-01-01T00:00:00+00:00\"},\"metrics\":{\"counter\":{\"browser.engagement.uri_count\":1,\"browser.engagement.active_ticks\":14},\"uuid\":{\"legacy.telemetry.client_id\":\"b22cb673-aa6d-4c48-b971-b86830eeb2cf\",\"legacy.telemetry.profile_group_id\":\"b22cb673-aa6d-4c48-b971-b86830eeb2cf\"}}}", 
		LAST);

	web_custom_request("8519743e-498d-4581-b229-cbb53d8e4794", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/events/1/8519743e-498d-4581-b229-cbb53d8e4794", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t69.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":128,\"start_time\":\"2024-12-01T10:11:39.000+05:00\",\"end_time\":\"2024-12-01T10:16:06.334+05:00\",\"reason\":\"startup\",\"experiments\":{\"fox-doodle-and-tail-fox-2024-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"disable-ads-startup-cache\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"phc-rollout\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"fx-accounts-ping-release-rollout-2\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"long-term-holdback-2024-h2-velocity-desktop\":{\"branch\":\"delivery\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"disabling-chips-for-v131\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"disable-redirects-for-authretries\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"consolidated-search-configuration-row-desktop-relaunch\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"highlighting-in-pdfs-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"extensions-migration-in-import-wizard-116-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"1-click-set-to-default-existing-profiles-rollout\":{\""
		"branch\":\"treatment-b\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"encrypted-client-hello-fallback-mechanism\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"61.2.0\",\"app_channel\":\"release\",\"app_build\":\"20241121140525\",\"app_display_version\":\"133.0\",\"locale\":\"ru\",\"architecture\":\""
		"x86_64\",\"os\":\"Windows\",\"os_version\":\"10.0\",\"client_id\":\"4691bf69-838a-4a5f-8495-dd6b7e5add4b\",\"windows_build_number\":22631,\"first_run_date\":\"2024-03-01+05:00\",\"build_date\":\"1970-01-01T00:00:00+00:00\"},\"metrics\":{\"quantity\":{\"urlbar.pref_max_results\":10},\"uuid\":{\"legacy.telemetry.client_id\":\"b22cb673-aa6d-4c48-b971-b86830eeb2cf\",\"legacy.telemetry.profile_group_id\":\"b22cb673-aa6d-4c48-b971-b86830eeb2cf\"},\"boolean\":{\"urlbar.pref_suggest_topsites\":true,\""
		"urlbar.pref_suggest_sponsored\":false,\"urlbar.pref_suggest_nonsponsored\":false,\"urlbar.pref_suggest_data_collection\":false}},\"events\":[{\"timestamp\":0,\"category\":\"session_restore\",\"name\":\"backup_can_be_loaded_session_file\",\"extra\":{\"glean_timestamp\":\"1733029897730\",\"path_key\":\"clean\",\"loadfail_reason\":\"N/A\",\"can_load\":\"true\"}},{\"timestamp\":0,\"category\":\"session_restore\",\"name\":\"backup_can_be_loaded_session_file\",\"extra\":{\"can_load\":\"true\",\""
		"path_key\":\"clean\",\"glean_timestamp\":\"1733029897730\",\"loadfail_reason\":\"N/A\"}},{\"timestamp\":1,\"category\":\"session_restore\",\"name\":\"shutdown_success_session_startup\",\"extra\":{\"shutdown_ok\":\"false\",\"glean_timestamp\":\"1733029897731\",\"shutdown_reason\":\"N/A\"}},{\"timestamp\":558,\"category\":\"webcompatreporting\",\"name\":\"reason_dropdown\",\"extra\":{\"setting\":\"required\",\"glean_timestamp\":\"1733029898288\"}},{\"timestamp\":1090,\"category\":\"doh\",\"name\":\""
		"state_enabled\",\"extra\":{\"value\":\"null\",\"glean_timestamp\":\"1733029898821\"}},{\"timestamp\":1091,\"category\":\"doh\",\"name\":\"evaluate_v2_heuristics\",\"extra\":{\"platform\":\"\",\"enterprise\":\"\",\"steeredProvider\":\"\",\"glean_timestamp\":\"1733029898821\",\"networkID\":\"hTVLDfon8t8+QJlsMtfh+S24k8NBt8sA+lNkUX3ixPw=\",\"value\":\"enable_doh\",\"canaries\":\"\",\"filtering\":\"\",\"evaluateReason\":\"startup\",\"captiveState\":\"unknown\"}},{\"timestamp\":1302,\"category\":\""
		"normandy\",\"name\":\"validation_failed_nimbus_experiment\",\"extra\":{\"value\":\"add-an-image-to-pdf-with-alt-text-rollout\",\"feature\":\"addAnImageInPDF\",\"reason\":\"invalid-feature\",\"glean_timestamp\":\"1733029899032\"}},{\"timestamp\":1302,\"category\":\"nimbus_events\",\"name\":\"validation_failed\",\"extra\":{\"feature\":\"addAnImageInPDF\",\"glean_timestamp\":\"1733029899032\",\"experiment\":\"add-an-image-to-pdf-with-alt-text-rollout\",\"reason\":\"invalid-feature\"}},{\"timestamp\""
		":1302,\"category\":\"normandy\",\"name\":\"validation_failed_nimbus_experiment\",\"extra\":{\"glean_timestamp\":\"1733029899032\",\"reason\":\"invalid-feature\",\"feature\":\"tabPreview\",\"value\":\"tab-hover-preview-release-rollout\"}},{\"timestamp\":1302,\"category\":\"nimbus_events\",\"name\":\"validation_failed\",\"extra\":{\"glean_timestamp\":\"1733029899032\",\"reason\":\"invalid-feature\",\"feature\":\"tabPreview\",\"experiment\":\"tab-hover-preview-release-rollout\"}},{\"timestamp\":1302,"
		"\"category\":\"nimbus_events\",\"name\":\"is_ready\",\"extra\":{\"glean_timestamp\":\"1733029899032\"}},{\"timestamp\":1348,\"category\":\"jsonfile\",\"name\":\"load_logins\",\"extra\":{\"value\":\"\",\"glean_timestamp\":\"1733029899078\"}},{\"timestamp\":1361,\"category\":\"upgrade_dialog\",\"name\":\"trigger_reason\",\"extra\":{\"value\":\"not-major\",\"glean_timestamp\":\"1733029899091\"}},{\"timestamp\":121592,\"category\":\"doh\",\"name\":\"state_enabled\",\"extra\":{\"glean_timestamp\":\""
		"1733030019322\",\"value\":\"null\"}},{\"timestamp\":121592,\"category\":\"doh\",\"name\":\"evaluate_v2_heuristics\",\"extra\":{\"value\":\"enable_doh\",\"enterprise\":\"\",\"networkID\":\"hTVLDfon8t8+QJlsMtfh+S24k8NBt8sA+lNkUX3ixPw=\",\"filtering\":\"\",\"evaluateReason\":\"connectivity\",\"steeredProvider\":\"\",\"glean_timestamp\":\"1733030019322\",\"canaries\":\"\",\"captiveState\":\"not_captive\",\"platform\":\"\"}},{\"timestamp\":121805,\"category\":\"network.dns\",\"name\":\""
		"trr_confirmation_context\",\"extra\":{\"value\":\"2\",\"glean_timestamp\":\"1733030019535\",\"captivePortal\":\"1\",\"results\":\"ttttttttt+\",\"contextReason\":\"pref-change\",\"trigger\":\"pref-change\",\"time\":\"120913.275500\",\"attemptCount\":\"10\",\"networkID\":\"jx+Q92jbXLl8sxiiCsfoRxeY/lA=\"}},{\"timestamp\":127717,\"category\":\"form_autocomplete\",\"name\":\"show_logins\",\"extra\":{\"insecureWarning\":\"1\",\"glean_timestamp\":\"1733030025447\",\"acFieldName\":\"\",\"loginsFooter\":\""
		"1\",\"fieldType\":\"text\",\"typeWasPassword\":\"0\",\"hadPrevious\":\"0\",\"stringLength\":\"0\",\"value\":\"24\"}},{\"timestamp\":129726,\"category\":\"form_autocomplete\",\"name\":\"show_logins\",\"extra\":{\"hadPrevious\":\"0\",\"glean_timestamp\":\"1733030027456\",\"stringLength\":\"1\",\"value\":\"8\",\"acFieldName\":\"\",\"loginsFooter\":\"1\",\"fieldType\":\"text\",\"insecureWarning\":\"1\",\"typeWasPassword\":\"0\"}},{\"timestamp\":263623,\"category\":\"doh\",\"name\":\"state_shutdown\","
		"\"extra\":{\"glean_timestamp\":\"1733030161354\",\"value\":\"null\"}}]}", 
		LAST);

	web_custom_request("b08f9bac-8d46-4c60-a06c-ce44529c0894", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/use-counters/1/b08f9bac-8d46-4c60-a06c-ce44529c0894", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t70.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":95,\"start_time\":\"2024-12-01T09:38:53.000+05:00\",\"end_time\":\"2024-12-01T10:10:18.096+05:00\",\"reason\":\"app_shutdown_confirmed\",\"experiments\":{\"highlighting-in-pdfs-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"encrypted-client-hello-fallback-mechanism\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"disable-redirects-for-authretries\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"fx-accounts-ping-release-rollout-2\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"1-click-set-to-default-existing-profiles-rollout\":{\"branch\":\"treatment-b\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"long-term-holdback-2024-h2-velocity-desktop\":{\"branch\":\"delivery\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"phc-rollout\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"disable-ads-startup-cache\":{\"branch\":\"control\",\"extra\":{\"type\":\""
		"nimbus-rollout\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"consolidated-search-configuration-row-desktop-relaunch\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"fox-doodle-and-tail-fox-2024-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"disabling-chips-for-v131\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\""
		"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"extensions-migration-in-import-wizard-116-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"61.2.0\",\"client_id\":\"4691bf69-838a-4a5f-8495-dd6b7e5add4b\",\"windows_build_number\":22631,\"build_date\":\"1970-01-01T00:00:00+00"
		":00\",\"first_run_date\":\"2024-03-01+05:00\",\"app_channel\":\"release\",\"app_build\":\"20241121140525\",\"locale\":\"ru\",\"os\":\"Windows\",\"os_version\":\"10.0\",\"architecture\":\"x86_64\",\"app_display_version\":\"133.0\"},\"metrics\":{\"counter\":{\"use.counter.css.page.css_font_size\":1,\"use.counter.top_level_content_documents_destroyed\":1,\"use.counter.css.doc.css_text_decoration\":6,\"use.counter.css.doc.css_font_family\":16,\"use.counter.css.doc.css_width\":2,\""
		"use.counter.dedicated_workers_destroyed\":1,\"use.counter.css.doc.css_font_size\":16,\"use.counter.css.doc.css_fill\":2,\"use.counter.content_documents_destroyed\":40,\"use.counter.css.doc.css_fill_opacity\":2,\"use.counter.css.page.css_color\":1,\"use.counter.css.doc.css_color\":16,\"use.counter.css.page.css_font_weight\":1,\"use.counter.css.doc.css_height\":2,\"use.counter.css.page.css_font_family\":1,\"use.counter.css.doc.css_font_weight\":6,\"use.counter.css.page.css_text_decoration\":1}}}", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_revert_auto_header("x-telemetry-agent");

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Sec-GPC", 
		"1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(4);

	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t71.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=140383.166869178HccAQfQpVtfiDDDDtDDcfpHftiHf", ENDITEM, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=bean", ENDITEM, 
		"Name=login.x", "Value=45", ENDITEM, 
		"Name=login.y", "Value=8", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t72.inf", 
		LAST);

	web_add_auto_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_submit_form("reservations.pl", 
		"Snapshot=t73.inf", 
		ITEMDATA, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value=12/02/2024", ENDITEM, 
		"Name=arrive", "Value=Los Angeles", ENDITEM, 
		"Name=returnDate", "Value=12/03/2024", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=<OFF>", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		LAST);

	web_submit_form("reservations.pl_2", 
		"Snapshot=t74.inf", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=030;251;12/02/2024", ENDITEM, 
		"Name=reserveFlights.x", "Value=64", ENDITEM, 
		"Name=reserveFlights.y", "Value=5", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_submit_form("reservations.pl_3", 
		"Snapshot=t75.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=Jojo", ENDITEM, 
		"Name=lastName", "Value=Bean", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		"Name=address2", "Value=", ENDITEM, 
		"Name=pass1", "Value=Jojo Bean", ENDITEM, 
		"Name=creditCard", "Value=", ENDITEM, 
		"Name=expDate", "Value=", ENDITEM, 
		"Name=saveCC", "Value=<OFF>", ENDITEM, 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_image("Itinerary Button", 
		"Alt=Itinerary Button", 
		"Ordinal=1", 
		"Snapshot=t76.inf", 
		LAST);

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_submit_form("itinerary.pl", 
		"Snapshot=t77.inf", 
		ITEMDATA, 
		"Name=1", "Value=on", ENDITEM, 
		LAST);

	return 0;
}